plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val ytdl = (project.findProperty("ytdlVersion") as String?) ?: "0.18.+"
// CPU types to include. Every extra type roughly adds the whole engine again (size!).
val abis = ((project.findProperty("abis") as String?) ?: "arm64-v8a").split(",").map { it.trim() }.filter { it.isNotEmpty() }

android {
    namespace = "com.mdsohel.shldownloader"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mdsohel.shldownloader"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += abis }
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    // yt-dlp / ffmpeg ship as native binaries that must be extracted at install time
    packaging { jniLibs { useLegacyPackaging = true } }
    lint { abortOnError = false }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("io.github.junkfood02.youtubedl-android:library:$ytdl")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:$ytdl")
}
