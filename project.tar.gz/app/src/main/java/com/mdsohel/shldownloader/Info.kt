package com.mdsohel.shldownloader

import java.util.Locale

data class QOpt(val height: Int, val size: Long, val h264: Boolean)

data class VideoInfo(
    val title: String,
    val thumbnail: String,
    val durationSec: Long,
    val uploader: String,
    val site: String,
    val heights: List<QOpt>,
    val isPlaylist: Boolean
)

/** One entry of the quality list shown on the preview screen. */
data class QChoice(val label: String, val mode: String, val height: Int?)

/** Turns yt-dlp's "-J" output into what the preview screen shows. Pure Kotlin. */
object Info {
    fun parse(json: String): VideoInfo? {
        val root = MiniJson.asMap(MiniJson.parse(json)) ?: return null
        val type = MiniJson.asString(root["_type"]) ?: "video"
        val title = MiniJson.asString(root["title"]) ?: MiniJson.asString(root["fulltitle"]) ?: ""
        if (type == "playlist" || type == "multi_video") {
            return VideoInfo(title, "", 0L, "", "", emptyList(), true)
        }
        var thumb = MiniJson.asString(root["thumbnail"]) ?: ""
        if (thumb.isBlank()) {
            val all = MiniJson.asList(root["thumbnails"])?.mapNotNull { MiniJson.asMap(it) } ?: emptyList()
            thumb = all.lastOrNull { !MiniJson.asString(it["url"]).isNullOrBlank() }?.let { MiniJson.asString(it["url"]) } ?: ""
        }
        val formats = MiniJson.asList(root["formats"])?.mapNotNull { MiniJson.asMap(it) } ?: emptyList()
        fun size(f: Map<String, Any?>): Long = MiniJson.asLong(f["filesize"]) ?: MiniJson.asLong(f["filesize_approx"]) ?: 0L
        fun hasVideo(f: Map<String, Any?>): Boolean = (MiniJson.asLong(f["height"]) ?: 0L) > 0L && MiniJson.asString(f["vcodec"]) != "none"
        fun isAudioOnly(f: Map<String, Any?>): Boolean {
            val a = MiniJson.asString(f["acodec"])
            return a != null && a != "none" && (MiniJson.asString(f["vcodec"]) == "none")
        }
        fun rate(f: Map<String, Any?>): Double = (f["tbr"] as? Double) ?: (MiniJson.asLong(f["tbr"])?.toDouble() ?: 0.0)

        // the app downloads AAC audio and H.264 video when they exist, so estimate the size from those
        fun abr(f: Map<String, Any?>): Double = (f["abr"] as? Double) ?: (MiniJson.asLong(f["abr"])?.toDouble() ?: 0.0)
        fun isH264(f: Map<String, Any?>): Boolean = (MiniJson.asString(f["vcodec"]) ?: "").let { it.startsWith("avc") || it.startsWith("h264") }
        val audios = formats.filter { isAudioOnly(it) }
        val aac = audios.filter { (MiniJson.asString(it["acodec"]) ?: "").startsWith("mp4a") }
        val bestAudio = (if (aac.isNotEmpty()) aac else audios).maxByOrNull { f -> abr(f) }
        val audioSize = bestAudio?.let { size(it) } ?: 0L
        val videos = formats.filter { hasVideo(it) }
        val heights = videos.map { (MiniJson.asLong(it["height"]) ?: 0L).toInt() }.distinct().sortedDescending()
        val opts = heights.map { h ->
            val cands = videos.filter { (MiniJson.asLong(it["height"]) ?: 0L).toInt() == h }
            val h264s = cands.filter { isH264(it) }
            val pick = (if (h264s.isNotEmpty()) h264s else cands).maxByOrNull { f -> rate(f) } ?: cands.first()
            val muxed = MiniJson.asString(pick["acodec"]).let { it != null && it != "none" }
            QOpt(h, size(pick) + (if (muxed) 0L else audioSize), h264s.isNotEmpty())
        }
        val site = MiniJson.asString(root["extractor_key"]) ?: MiniJson.asString(root["extractor"]) ?: ""
        val uploader = MiniJson.asString(root["uploader"]) ?: MiniJson.asString(root["channel"]) ?: ""
        return VideoInfo(title, thumb, MiniJson.asLong(root["duration"]) ?: 0L, uploader, site, opts, false)
    }

    fun fmtSize(bytes: Long): String =
        if (bytes >= 1_000_000_000L) String.format(Locale.US, "%.2f GB", bytes / 1e9)
        else "${(bytes / 1_000_000L).coerceAtLeast(1L)} MB"

    fun fmtDuration(sec: Long): String {
        if (sec <= 0L) return ""
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
    }

    private val HOST = Regex("""^https?://(?:www\.|m\.)?([^/:?#]+)""", RegexOption.IGNORE_CASE)
    fun hostOf(url: String): String = HOST.find(url.trim())?.groupValues?.get(1) ?: ""

    /** "YouTube · 4:32 · Channel name" */
    fun metaLine(info: VideoInfo?, url: String): String =
        listOf(hostOf(url), info?.let { fmtDuration(it.durationSec) } ?: "", info?.uploader ?: "")
            .filter { it.isNotBlank() }
            .joinToString(" · ")

    fun label(o: QOpt): String = buildString {
        append(Logic.qualityLabel(o.height))
        if (o.size > 0L) append(" · ~").append(fmtSize(o.size))
        if (!o.h264) append(" · VP9/AV1 (VLC লাগতে পারে)")
    }

    /** Spinner entries: best, each real quality of this video (or common presets when unknown), MP3. */
    fun choices(info: VideoInfo?): List<QChoice> {
        val list = ArrayList<QChoice>()
        list.add(QChoice("সেরা কোয়ালিটি (MP4 · সব প্লেয়ারে চলে)", "video", null))
        val real = info?.heights?.filter { it.height >= 144 } ?: emptyList()
        if (real.isNotEmpty()) {
            real.forEach { list.add(QChoice(label(it), "video", it.height)) }
        } else {
            Logic.QUALITIES.filterNotNull().forEach { list.add(QChoice(Logic.qualityLabel(it), "video", it)) }
        }
        list.add(QChoice("♫ শুধু অডিও (MP3)", "audio", null))
        return list
    }
}
