package com.mdsohel.shldownloader

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import java.io.File
import java.io.IOException

/** Moves a finished file from the private work folder to where the user can see it. */
object Storage {
    fun save(ctx: Context, file: File, mode: String): Uri {
        val name = Logic.cleanName(file.name)
        val mime = Logic.mimeFor(file.extension)
        val tree = Prefs.tree(ctx)
        if (tree != null) {
            try {
                val uri = saveToTree(ctx, tree, file, name, mime)
                file.delete()
                return uri
            } catch (_: Exception) {
                // the chosen folder is gone or not writable: fall back to the default place
            }
        }
        val uri = saveToMediaStore(ctx, file, name, mime)
        file.delete()
        return uri
    }

    private fun saveToTree(ctx: Context, tree: Uri, file: File, name: String, mime: String): Uri {
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val doc = DocumentsContract.createDocument(ctx.contentResolver, parent, mime, name)
            ?: throw IOException("could not create file in the chosen folder")
        ctx.contentResolver.openOutputStream(doc)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        } ?: throw IOException("could not open the new file")
        return doc
    }

    private fun saveToMediaStore(ctx: Context, file: File, name: String, mime: String): Uri {
        val isAudio = mime.startsWith("audio")
        val isVideo = mime.startsWith("video")
        val collection = when {
            isAudio -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            isVideo -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else -> MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }
        val folder = when {
            isAudio -> "Music/SHL Downloader"
            isVideo -> "Movies/SHL Downloader"
            else -> "Download/SHL Downloader"
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(collection, values) ?: throw IOException("MediaStore insert failed")
        try {
            resolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            } ?: throw IOException("could not open output")
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return uri
    }
}
