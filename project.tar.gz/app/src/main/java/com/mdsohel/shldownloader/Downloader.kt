package com.mdsohel.shldownloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object Downloader {
    /** Runs one job to completion. [onProgress] gets (title, percent) for the notification. */
    suspend fun run(ctx: Context, jobId: String, onProgress: (String, Int) -> Unit) {
        withContext(Dispatchers.IO) {
            val job = JobStore.get(jobId) ?: return@withContext
            if (job.status == "cancelled") return@withContext
            JobStore.update(jobId) { it.copy(status = "running", text = "শুরু হচ্ছে…") }

            if (!Engine.awaitReady()) {
                JobStore.update(jobId) { it.copy(status = "error", text = "ব্যর্থ", error = "ইঞ্জিন চালু হয়নি: ${Engine.error}") }
                return@withContext
            }

            val dir = File(ctx.cacheDir, "dl/$jobId")
            dir.mkdirs()
            try {
                val request = YoutubeDLRequest(job.url)
                for (o in Logic.options(job.mode, job.height, dir.absolutePath)) {
                    if (o.size == 1) request.addOption(o[0]) else request.addOption(o[0], o[1])
                }
                var stage = 0
                YoutubeDL.getInstance().execute(request, jobId) { progress, eta, line ->
                    val l = line.toString()
                    if (l.contains("Destination:")) stage++
                    val found = Logic.titleFromLine(l)
                    val text: String? = when {
                        l.contains("[Merger]") -> "ভিডিও + অডিও জোড়া লাগানো হচ্ছে…"
                        l.contains("[ExtractAudio]") -> "MP3 বানানো হচ্ছে…"
                        l.contains("[VideoRemuxer]") -> "MP4 তৈরি হচ্ছে…"
                        progress >= 0f -> if (stage > 1) "ডাউনলোড হচ্ছে (ধাপ $stage)" else "ডাউনলোড হচ্ছে"
                        else -> null
                    }
                    var shownTitle = ""
                    JobStore.update(jobId) { cur ->
                        if (cur.status == "cancelled") {
                            cur
                        } else {
                            val t = if (found != null && cur.title == cur.url) found else cur.title
                            shownTitle = t
                            cur.copy(
                                title = t,
                                percent = if (progress >= 0f) progress else cur.percent,
                                eta = if (progress >= 0f) eta else cur.eta,
                                text = text ?: cur.text
                            )
                        }
                    }
                    if (progress >= 0f) onProgress(shownTitle, progress.toInt())
                }

                if (JobStore.get(jobId)?.status == "cancelled") return@withContext

                val files = dir.listFiles()?.filter { it.isFile }?.map { Logic.F(it.name, it.length()) } ?: emptyList()
                val pick = Logic.pickOutput(files, job.mode)
                    ?: throw IllegalStateException("ফাইল তৈরি হয়নি (সাইট ব্লক করেছে বা ফরম্যাট মেলেনি)")
                JobStore.update(jobId) { it.copy(text = "ফোনে সেভ হচ্ছে…", percent = 99f) }
                val uri = Storage.save(ctx, File(dir, pick.name), job.mode)
                val nice = Logic.cleanName(pick.name).substringBeforeLast('.')
                JobStore.update(jobId) {
                    it.copy(status = "done", percent = 100f, text = "সম্পন্ন", eta = -1L, saved = uri.toString(), title = nice)
                }
            } catch (e: Exception) {
                if (JobStore.get(jobId)?.status != "cancelled") {
                    JobStore.update(jobId) { it.copy(status = "error", text = "ব্যর্থ", error = Logic.friendlyError(e.message)) }
                }
            } finally {
                dir.deleteRecursively()
            }
        }
    }

    fun cancel(jobId: String) {
        JobStore.update(jobId) { if (it.status == "queued" || it.status == "running") it.copy(status = "cancelled", text = "বাতিল") else it }
        try {
            YoutubeDL.getInstance().destroyProcessById(jobId)
        } catch (_: Throwable) {
        }
    }
}
