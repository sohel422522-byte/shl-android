package com.mdsohel.shldownloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

object Downloader {
    /** Runs one job to completion. [onProgress] gets (title, percent) for the notification. */
    suspend fun run(ctx: Context, jobId: String, onProgress: (String, Int) -> Unit) {
        withContext(Dispatchers.IO) {
            val job = JobStore.get(jobId) ?: return@withContext
            if (job.status == "cancelled") return@withContext
            JobStore.update(jobId) { it.copy(status = "running", text = "শুরু হচ্ছে…") }

            if (!Engine.awaitReady()) {
                JobStore.update(jobId) { it.copy(status = "error", text = "ব্যর্থ", error = "ইঞ্জিন চালু হয়নি: ${Engine.error}") }
                return@withContext
            }

            // seconds counter, so you can see it is alive while yt-dlp prepares
            val ticker = CoroutineScope(Dispatchers.Default).launch {
                val t0 = System.currentTimeMillis()
                while (true) {
                    delay(1000)
                    val sec = ((System.currentTimeMillis() - t0) / 1000).toInt()
                    JobStore.update(jobId) { if (it.status == "running" && it.percent <= 0f) it.copy(elapsed = sec) else it }
                }
            }
            val dir = File(ctx.cacheDir, "dl/$jobId")
            try {
                var useJs = jsEngine(ctx).exists()
                var failure: Exception? = null
                var ok = false
                for (round in 1..2) {
                    dir.deleteRecursively()
                    dir.mkdirs()
                    try {
                        attempt(ctx, job, dir, useJs, onProgress)
                        ok = true
                        break
                    } catch (e: Exception) {
                        failure = e
                        if (JobStore.get(jobId)?.status == "cancelled") break
                        // an older yt-dlp does not know the JS options: retry once without them
                        if (useJs && (e.message ?: "").contains("js-runtimes", ignoreCase = true)) {
                            useJs = false
                            JobStore.update(jobId) { it.copy(text = "সাধারণ পদ্ধতিতে আবার চেষ্টা হচ্ছে…", percent = 0f, eta = -1L) }
                        } else {
                            break
                        }
                    }
                }
                if (JobStore.get(jobId)?.status == "cancelled") return@withContext
                if (!ok) throw (failure ?: IllegalStateException("ডাউনলোড ব্যর্থ"))

                val files = dir.listFiles()?.filter { it.isFile }?.map { Logic.F(it.name, it.length()) } ?: emptyList()
                val pick = Logic.pickOutput(files, job.mode)
                    ?: throw IllegalStateException("ফাইল তৈরি হয়নি (সাইট ব্লক করেছে বা ফরম্যাট মেলেনি)")
                JobStore.update(jobId) { it.copy(text = "ফোনে সেভ হচ্ছে…", percent = 99f) }
                val uri = Storage.save(ctx, File(dir, pick.name), job.mode)
                val nice = Logic.cleanName(pick.name).substringBeforeLast('.')
                JobStore.update(jobId) {
                    it.copy(status = "done", percent = 100f, text = "সম্পন্ন", eta = -1L, saved = uri.toString(), title = nice)
                }
            } catch (e: Exception) {
                if (JobStore.get(jobId)?.status != "cancelled") {
                    JobStore.update(jobId) { it.copy(status = "error", text = "ব্যর্থ", error = Logic.friendlyError(e.message)) }
                }
            } finally {
                ticker.cancel()
                dir.deleteRecursively()
            }
        }
    }

    /** QuickJS (a tiny JavaScript engine) packed with the app; yt-dlp needs one to solve YouTube's challenges. */
    private fun jsEngine(ctx: Context): File = File(ctx.applicationInfo.nativeLibraryDir, "libqjs.so")

    /** One yt-dlp run. Throws when it fails. */
    private fun attempt(ctx: Context, job: DlJob, dir: File, useJs: Boolean, onProgress: (String, Int) -> Unit) {
        val jobId = job.id
        val request = YoutubeDLRequest(job.url)
        for (o in Logic.options(job.mode, job.height, dir.absolutePath)) {
            if (o.size == 1) request.addOption(o[0]) else request.addOption(o[0], o[1])
        }
        // keep YouTube's player code between downloads: the 2nd download onwards starts much faster
        request.addOption("--cache-dir", File(ctx.filesDir, "yt-cache").absolutePath)
        if (useJs) {
            // without a JS engine yt-dlp skips YouTube's normal clients and wastes a minute on fallbacks
            request.addOption("--js-runtimes", "quickjs:" + jsEngine(ctx).absolutePath)
            request.addOption("--remote-components", "ejs:github")
        }

        var stage = 0
        YoutubeDL.getInstance().execute(request, jobId) { progress, eta, line ->
            val l = line.toString()
            if (l.contains("Destination:")) stage++
            val found = Logic.titleFromLine(l)
            val text: String? = when {
                l.contains("[Merger]") -> "ভিডিও + অডিও জোড়া লাগানো হচ্ছে…"
                l.contains("[ExtractAudio]") -> "MP3 বানানো হচ্ছে…"
                l.contains("[VideoRemuxer]") -> "MP4 তৈরি হচ্ছে…"
                l.contains("[download]") && progress >= 0f -> if (stage > 1) "ডাউনলোড হচ্ছে (ধাপ $stage)" else "ডাউনলোড হচ্ছে"
                else -> Logic.stageFromLine(l)
            }
            var shownTitle = ""
            JobStore.update(jobId) { cur ->
                if (cur.status == "cancelled") {
                    cur
                } else {
                    val t = if (found != null && cur.title == cur.url) found else cur.title
                    shownTitle = t
                    cur.copy(
                        title = t,
                        percent = if (progress >= 0f) progress else cur.percent,
                        eta = if (progress >= 0f) eta else cur.eta,
                        text = text ?: cur.text
                    )
                }
            }
            if (progress >= 0f) onProgress(shownTitle, progress.toInt())
        }
    }

    fun cancel(jobId: String) {
        JobStore.update(jobId) { if (it.status == "queued" || it.status == "running") it.copy(status = "cancelled", text = "বাতিল") else it }
        try {
            YoutubeDL.getInstance().destroyProcessById(jobId)
        } catch (_: Throwable) {
        }
    }
}
