package com.mdsohel.shldownloader

/** Pure logic (no Android classes) so it can be unit-tested anywhere. */
object Logic {
    val QUALITIES: List<Int?> = listOf(null, 2160, 1440, 1080, 720, 480, 360)

    fun qualityLabel(h: Int?): String {
        val x = h ?: return "সেরা কোয়ালিটি (MP4)"
        return when {
            x >= 2160 -> "${x}p · 4K"
            x >= 1440 -> "${x}p · 2K"
            x >= 1080 -> "${x}p · Full HD"
            x >= 720 -> "${x}p · HD"
            else -> "${x}p"
        }
    }

    private val LINK = Regex("""https?://[^\s<>"'“”‘’]+""", RegexOption.IGNORE_CASE)

    /** Video links inside text shared from Facebook/YouTube/etc. */
    fun extractLinks(text: String?): List<String> {
        if (text.isNullOrBlank()) return emptyList()
        return LINK.findAll(text)
            .map { it.value.trimEnd(')', ']', '}', '.', ',', ';', ':', '!', '?', '।') }
            .filter { it.length > 8 }
            .distinct()
            .toList()
    }

    /**
     * yt-dlp options for one download. Video: MP4 that plays in any player (H.264 + AAC preferred),
     * highest quality not above [height] (null = best). Audio: always MP3.
     */
    fun options(mode: String, height: Int?, outDir: String): List<List<String>> {
        val o = mutableListOf<List<String>>()
        o += listOf("--no-playlist")
        o += listOf("--no-mtime")
        o += listOf("--windows-filenames")
        o += listOf("-o", "$outDir/%(title).120B [%(id)s].%(ext)s")
        if (mode == "audio") {
            o += listOf("-f", "ba/b")
            o += listOf("-x")
            o += listOf("--audio-format", "mp3")
            o += listOf("--audio-quality", "0")
        } else {
            val sel = if (height != null) "bv*[height<=$height]+ba/b[height<=$height]/b" else "bv*+ba/b"
            val sort = if (height != null) "res:$height,vcodec:h264,acodec:m4a" else "vcodec:h264,res,acodec:m4a"
            o += listOf("-f", sel)
            o += listOf("-S", sort)
            o += listOf("--merge-output-format", "mp4")
            o += listOf("--remux-video", "mp4")
        }
        o += listOf("-N", "4")
        return o
    }

    data class F(val name: String, val size: Long)

    /** Picks the finished file out of yt-dlp's working folder (ignores partials and thumbnails). */
    fun pickOutput(files: List<F>, mode: String): F? {
        val want = if (mode == "audio") ".mp3" else ".mp4"
        val skip = listOf(".part", ".ytdl", ".temp", ".json", ".jpg", ".jpeg", ".png", ".webp", ".vtt", ".srt")
        return files
            .filter { f -> f.size > 0 && skip.none { f.name.lowercase().endsWith(it) } }
            .sortedWith(compareBy<F>({ !it.name.lowercase().endsWith(want) }, { -it.size }))
            .firstOrNull()
    }

    private val ID_SUFFIX = Regex("""\s*\[[\w-]{6,}\](?=\.\w+$)""")

    /** "My video [dQw4w9WgXcQ].mp4" -> "My video.mp4" */
    fun cleanName(name: String): String = name.replace(ID_SUFFIX, "")

    private val DEST = Regex("""Destination:\s*.*/(.+?)\s*\[[^\]]+\](?:\.f\d+)?\.\w+$""")

    /** Title taken from yt-dlp's "[download] Destination: ..." line, or null. */
    fun titleFromLine(line: String): String? = DEST.find(line.trim())?.groupValues?.get(1)?.takeIf { it.isNotBlank() }

    private val YT = Regex("""^https?://([\w-]+\.)*(youtube\.com|youtu\.be)(/|$|\?)""", RegexOption.IGNORE_CASE)

    fun isYoutube(url: String): Boolean = YT.containsMatchIn(url.trim())

    /** yt-dlp prints what it is doing; show it in Bengali so the user sees progress while it prepares. */
    fun stageFromLine(l: String): String? = when {
        l.contains("Extracting URL") -> "ভিডিওর তথ্য পড়া হচ্ছে…"
        l.contains("Downloading webpage") -> "পেজ পড়া হচ্ছে…"
        l.contains("Downloading player") || l.contains("nsig") || l.contains("n-sig") ->
            "YouTube প্লেয়ার কোড বিশ্লেষণ হচ্ছে (প্রথমবার ধীর, পরের বার দ্রুত)…"
        l.contains("API JSON") -> "সাইটের সাথে যোগাযোগ হচ্ছে…"
        l.contains("m3u8 information") || l.contains("MPD manifest") -> "স্ট্রিমের তালিকা পড়া হচ্ছে…"
        l.contains("[info]") && l.contains("Downloading") && l.contains("format") -> "ডাউনলোড শুরু হচ্ছে…"
        else -> null
    }

    fun mimeFor(ext: String): String = when (ext.lowercase()) {
        "mp4", "m4v" -> "video/mp4"
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "ogg", "opus" -> "audio/ogg"
        "wav" -> "audio/x-wav"
        else -> "application/octet-stream"
    }

    fun formatEta(sec: Long): String = if (sec < 0) "" else "${sec / 60}:${(sec % 60).toString().padStart(2, '0')}"

    private val ANSI = Regex("\u001B\\[[0-9;]*m")

    /** Short Bengali explanation + the last line of yt-dlp's message. */
    fun friendlyError(raw: String?): String {
        val m = ANSI.replace(raw ?: "", "").trim()
        fun has(p: String) = Regex(p, RegexOption.IGNORE_CASE).containsMatchIn(m)
        val hint = when {
            has("Sign in|not a bot|confirm you.re not") ->
                "YouTube সাইন-ইন চাইছে। মোবাইল ডেটা/ওয়াইফাই বদলে চেষ্টা করুন, আর “ইঞ্জিন আপডেট” চাপুন।"
            has("Unsupported URL") -> "এই লিংক সাপোর্টেড নয়, অথবা লগইন লাগে।"
            has("Unable to resolve host|Network is unreachable|timed out|Unable to connect") -> "ইন্টারনেট সংযোগে সমস্যা।"
            has("ffmpeg|Postprocessing") -> "ভিডিও/অডিও প্রক্রিয়াকরণে সমস্যা হয়েছে।"
            has("HTTP Error 403|403: Forbidden") -> "সাইট অনুরোধ আটকেছে (403)। “ইঞ্জিন আপডেট” দিয়ে আবার চেষ্টা করুন।"
            has("Private video|login|registered|cookies") -> "ভিডিওটা প্রাইভেট বা লগইন লাগে — এই অ্যাপে এটা সম্ভব নয়।"
            else -> ""
        }
        val tail = m.lineSequence().lastOrNull { it.isNotBlank() }?.take(200) ?: ""
        return if (hint.isEmpty()) tail else if (tail.isEmpty()) hint else "$hint\n($tail)"
    }
}
