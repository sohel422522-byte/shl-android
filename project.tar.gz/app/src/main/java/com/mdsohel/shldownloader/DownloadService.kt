package com.mdsohel.shldownloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/** Keeps downloads alive while the app is in the background. */
class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val gate = Semaphore(2)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, notification("SHL Downloader", "ডাউনলোড চলছে…", -1),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        val id = intent?.getStringExtra("id")
        if (id == null) {
            stopIfIdle()
            return START_NOT_STICKY
        }
        scope.launch {
            gate.withPermit {
                Downloader.run(applicationContext, id) { title, pct -> updateNotification(title, pct) }
            }
            announceResult(id)
            stopIfIdle()
        }
        return START_NOT_STICKY
    }

    private fun stopIfIdle() {
        if (!JobStore.hasActive()) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun ensureChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "ডাউনলোড", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(title: String, text: String, pct: Int, ongoing: Boolean = true): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(if (ongoing) android.R.drawable.stat_sys_download else android.R.drawable.stat_sys_download_done)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
        if (ongoing) b.setProgress(100, pct.coerceAtLeast(0), pct < 0)
        return b.build()
    }

    private fun updateNotification(title: String, pct: Int) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, notification(title.ifBlank { "SHL Downloader" }, "ডাউনলোড হচ্ছে… $pct%", pct))
    }

    private fun announceResult(id: String) {
        val job = JobStore.get(id) ?: return
        val text = when (job.status) {
            "done" -> "সম্পন্ন ✓"
            "error" -> "ব্যর্থ — অ্যাপ খুলে দেখুন"
            else -> return
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(id.hashCode(), notification(job.title.ifBlank { "SHL Downloader" }, text, 100, ongoing = false))
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "downloads"
        private const val NOTIF_ID = 1
    }
}
