package com.mdsohel.shldownloader

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private lateinit var etLinks: EditText
    private lateinit var banner: View
    private lateinit var tvBanner: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var tvEngine: TextView
    private lateinit var adapter: JobAdapter
    private var offeredClip: String = ""

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                Prefs.setTree(this, uri)
                toast("ফোল্ডার সেভ হয়েছে ✓ — এখন থেকে ফাইল এখানে যাবে")
            } catch (e: Exception) {
                toast("এই ফোল্ডার ব্যবহার করা যাচ্ছে না — অন্য ফোল্ডার বাছুন")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etLinks = findViewById(R.id.etLinks)
        banner = findViewById(R.id.banner)
        tvBanner = findViewById(R.id.tvBanner)
        tvEmpty = findViewById(R.id.tvEmpty)
        tvEngine = findViewById(R.id.tvEngine)

        adapter = JobAdapter(
            onCancel = { Downloader.cancel(it.id) },
            onOpen = { openFile(it) },
            onRemove = { Downloader.cancel(it.id); JobStore.remove(it.id) }
        )
        val rv = findViewById<RecyclerView>(R.id.rvJobs)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        findViewById<Button>(R.id.btnPaste).setOnClickListener { pasteFromClipboard() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { etLinks.setText("") }
        findViewById<Button>(R.id.btnQuick).setOnClickListener { start("video", null) }
        findViewById<Button>(R.id.btnMp3).setOnClickListener { start("audio", null) }
        findViewById<Button>(R.id.btnChoose).setOnClickListener { chooseQuality() }
        findViewById<View>(R.id.btnClearJobs).setOnClickListener { JobStore.clearFinished() }
        findViewById<Button>(R.id.btnFolder).setOnClickListener { folderDialog() }
        findViewById<Button>(R.id.btnUpdate).setOnClickListener { updateEngine() }
        findViewById<Button>(R.id.btnBannerNo).setOnClickListener {
            Prefs.setLastClip(this, offeredClip)
            banner.visibility = View.GONE
        }
        findViewById<Button>(R.id.btnBannerUse).setOnClickListener {
            Prefs.setLastClip(this, offeredClip)
            banner.visibility = View.GONE
            etLinks.setText(offeredClip)
            chooseQuality()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    JobStore.jobs.collect { list ->
                        adapter.submitList(list)
                        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                    }
                }
                launch { Engine.status.collect { tvEngine.text = it } }
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) checkClipboard()
    }

    /** Android "Share" -> this app. */
    private fun handleIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: i.getStringExtra(Intent.EXTRA_SUBJECT)
        val links = Logic.extractLinks(text)
        if (links.isEmpty()) {
            toast("শেয়ার করা লেখায় কোনো লিংক পাওয়া যায়নি")
            return
        }
        etLinks.setText(links.joinToString("\n"))
        if (links.size == 1) chooseQuality()
    }

    private fun clipText(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        return clip.getItemAt(0).coerceToText(this)?.toString()
    }

    private fun pasteFromClipboard() {
        val t = clipText()
        if (t.isNullOrBlank()) toast("ক্লিপবোর্ড খালি") else etLinks.setText(t)
    }

    /** A link was copied outside the app? Offer it with one tap. */
    private fun checkClipboard() {
        if (etLinks.text.isNotBlank()) return
        val first = Logic.extractLinks(clipText()).firstOrNull() ?: return
        if (first == Prefs.lastClip(this)) return
        offeredClip = first
        tvBanner.text = "📋 কপি করা লিংক: " + first.removePrefix("https://").removePrefix("http://").removePrefix("www.")
        banner.visibility = View.VISIBLE
    }

    private fun links(): List<String> = Logic.extractLinks(etLinks.text.toString())

    private fun start(mode: String, height: Int?) {
        val ls = links()
        if (ls.isEmpty()) {
            toast("আগে লিংক পেস্ট করুন")
            return
        }
        ls.forEach { enqueue(it, mode, height) }
    }

    private fun enqueue(url: String, mode: String, height: Int?) {
        val id = UUID.randomUUID().toString().take(12)
        JobStore.add(DlJob(id = id, url = url, mode = mode, height = height, title = url, text = "লাইনে আছে"))
        ContextCompat.startForegroundService(this, Intent(this, DownloadService::class.java).putExtra("id", id))
    }

    private fun chooseQuality() {
        if (links().isEmpty()) {
            toast("আগে লিংক পেস্ট করুন")
            return
        }
        val labels = Logic.QUALITIES.map { Logic.qualityLabel(it) } + "♫ শুধু অডিও (MP3)"
        var picked = 0
        AlertDialog.Builder(this)
            .setTitle("কোয়ালিটি বাছুন")
            .setSingleChoiceItems(labels.toTypedArray(), 0) { _, which -> picked = which }
            .setPositiveButton("⬇ ডাউনলোড") { _, _ ->
                if (picked == labels.size - 1) start("audio", null) else start("video", Logic.QUALITIES[picked])
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun folderDialog() {
        val items = arrayOf("📁 নিজের ফোল্ডার বাছুন", "↩ ডিফল্ট (Movies / Music › SHL Downloader)")
        AlertDialog.Builder(this)
            .setTitle("কোথায় সেভ হবে?")
            .setItems(items) { _, which ->
                if (which == 0) {
                    toast("ফোল্ডার বেছে নিচে “এই ফোল্ডার ব্যবহার করুন” চাপুন")
                    folderPicker.launch(null)
                } else {
                    Prefs.setTree(this, null)
                    toast("ডিফল্ট ফোল্ডারে ফিরে এসেছে")
                }
            }
            .show()
    }

    private fun updateEngine() {
        toast("yt-dlp আপডেট হচ্ছে…")
        lifecycleScope.launch {
            val msg = withContext(Dispatchers.IO) { Engine.update(applicationContext) }
            toast(msg)
        }
    }

    private fun openFile(j: DlJob) {
        try {
            val uri = Uri.parse(j.saved)
            val type = contentResolver.getType(uri) ?: "*/*"
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, type).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            toast("ফাইল খোলা যায়নি — ফাইল অ্যাপে Movies/SHL Downloader দেখুন")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
