package com.mdsohel.shldownloader

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.UUID

/** One link on the preview screen. */
class PItem(val url: String) {
    val id: String = UUID.randomUUID().toString().take(10)
    var state: String = "loading"      // loading | ready | error
    var info: VideoInfo? = null
    var infoPath: String = ""
    var error: String = ""
    var thumb: Bitmap? = null
    var checked: Boolean = true
}

/**
 * Shows WHAT will be downloaded (picture, title, length, channel, real qualities) before anything is saved,
 * for one link or many (bulk). Download only starts when you press the button.
 */
class PreviewActivity : AppCompatActivity() {
    private val items = ArrayList<PItem>()
    private lateinit var adapter: PreviewAdapter
    private lateinit var spQuality: Spinner
    private lateinit var btnGo: Button
    private lateinit var tvHint: TextView
    private var choices: List<QChoice> = Info.choices(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preview)
        val links = intent.getStringArrayListExtra("links") ?: ArrayList()
        val pre = intent.getStringExtra("pre") ?: ""
        if (links.isEmpty()) {
            finish()
            return
        }
        links.forEach { items.add(PItem(it)) }

        spQuality = findViewById(R.id.spQuality)
        btnGo = findViewById(R.id.btnGo)
        tvHint = findViewById(R.id.tvHint)
        val rv = findViewById<RecyclerView>(R.id.rvPreview)
        adapter = PreviewAdapter(items) { updateButton() }
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        findViewById<Button>(R.id.btnCancel).setOnClickListener { finish() }
        btnGo.setOnClickListener { download() }
        setChoices(Info.choices(null), null, pre == "audio")
        updateButton()

        val gate = Semaphore(2)
        items.forEachIndexed { index, item ->
            lifecycleScope.launch { gate.withPermit { load(index, item) } }
        }
    }

    private fun setChoices(list: List<QChoice>, keep: QChoice?, preferAudio: Boolean) {
        choices = list
        spQuality.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, list.map { it.label })
        val idx = when {
            keep != null -> list.indexOfFirst { it.mode == keep.mode && it.height == keep.height }.let { if (it >= 0) it else 0 }
            preferAudio -> list.indexOfFirst { it.mode == "audio" }.let { if (it >= 0) it else 0 }
            else -> 0
        }
        spQuality.setSelection(idx)
    }

    private fun current(): QChoice = choices.getOrElse(spQuality.selectedItemPosition) { choices.first() }

    private suspend fun load(index: Int, item: PItem) {
        try {
            val r = InfoFetcher.fetch(applicationContext, item.url, item.id)
            item.info = r.info
            item.infoPath = r.path
            item.state = "ready"
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            item.state = "error"
            item.error = Logic.friendlyError(e.message)
        }
        adapter.notifyItemChanged(index)
        updateButton()
        if (item.state == "ready") {
            // a single video: show its real qualities; several: keep the common list
            if (items.size == 1) setChoices(Info.choices(item.info), current(), false)
            val t = item.info?.thumbnail ?: ""
            if (t.isNotBlank()) {
                item.thumb = withContext(Dispatchers.IO) { Thumbs.load(t) }
                adapter.notifyItemChanged(index)
            }
        }
    }

    private fun updateButton() {
        val n = items.count { it.checked }
        btnGo.text = "⬇ ডাউনলোড ($n)"
        btnGo.isEnabled = n > 0
        val loading = items.count { it.state == "loading" }
        tvHint.text = if (loading > 0) "কিছু তথ্য এখনও পড়া হচ্ছে — চাইলে অপেক্ষা করে দেখে নিন, অথবা এখনই ডাউনলোড দিন।" else ""
    }

    private fun download() {
        val c = current()
        var n = 0
        for (item in items) {
            if (!item.checked) continue
            Jobs.enqueue(applicationContext, item.url, c.mode, c.height, item.infoPath, item.info?.title ?: "")
            n++
        }
        if (n == 0) {
            Toast.makeText(this, "কিছু বাছা হয়নি", Toast.LENGTH_SHORT).show()
            return
        }
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        items.filter { it.state == "loading" }.forEach { InfoFetcher.cancel(it.id) }
    }
}

class PreviewAdapter(
    private val items: List<PItem>,
    private val onChange: () -> Unit
) : RecyclerView.Adapter<PreviewAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.ivThumb)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val meta: TextView = v.findViewById(R.id.tvMeta)
        val state: TextView = v.findViewById(R.id.tvState)
        val bar: ProgressBar = v.findViewById(R.id.pbLoad)
        val check: CheckBox = v.findViewById(R.id.cbPick)
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_preview, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        val title = item.info?.title ?: ""
        h.title.text = if (title.isNotBlank()) title else item.url
        h.meta.text = Info.metaLine(item.info, item.url)
        h.img.setImageBitmap(item.thumb)
        when (item.state) {
            "loading" -> {
                h.bar.visibility = View.VISIBLE
                h.state.visibility = View.VISIBLE
                h.state.text = "তথ্য পড়া হচ্ছে…"
                h.state.setTextColor(0xFF5F6368.toInt())
            }
            "error" -> {
                h.bar.visibility = View.GONE
                h.state.visibility = View.VISIBLE
                h.state.text = item.error
                h.state.setTextColor(0xFFC5221F.toInt())
            }
            else -> {
                h.bar.visibility = View.GONE
                h.state.visibility = View.GONE
            }
        }
        // tap the picture to open the real link and double-check it is the right video
        h.img.setOnClickListener {
            try {
                h.itemView.context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.url)))
            } catch (e: Exception) {
            }
        }
        h.check.setOnCheckedChangeListener(null)
        h.check.isChecked = item.checked
        h.check.setOnCheckedChangeListener { _, checked ->
            item.checked = checked
            onChange()
        }
    }
}
