package com.mdsohel.shldownloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Reads a video's title, picture and real qualities WITHOUT downloading it (yt-dlp -J). */
object InfoFetcher {
    class Result(val info: VideoInfo, val path: String)

    suspend fun fetch(ctx: Context, url: String, id: String): Result = withContext(Dispatchers.IO) {
        if (!Engine.awaitReady()) throw IllegalStateException("ইঞ্জিন চালু হয়নি: ${Engine.error}")
        var useJs = Engine.jsEngineFile(ctx).exists()
        var last: Exception? = null
        for (round in 1..2) {
            try {
                val request = YoutubeDLRequest(url)
                request.addOption("-J")
                request.addOption("--no-playlist")
                request.addOption("--no-warnings")
                Engine.applyCommon(ctx, request, useJs)
                val response = YoutubeDL.getInstance().execute(request, "info-$id")
                val text = response.out.trim()
                val start = text.indexOf('{')
                val json = if (start >= 0) text.substring(start) else text
                val info = Info.parse(json) ?: throw IllegalStateException("ভিডিওর তথ্য পড়া যায়নি")
                if (info.isPlaylist) throw IllegalStateException("এটা প্লেলিস্ট — একটা ভিডিওর লিংক দিন")
                val file = File(ctx.cacheDir, "info/$id.json")
                file.parentFile?.mkdirs()
                file.writeText(json)
                return@withContext Result(info, file.absolutePath)
            } catch (e: Exception) {
                last = e
                if (useJs && (e.message ?: "").contains("js-runtimes", ignoreCase = true)) useJs = false else break
            }
        }
        throw (last ?: IllegalStateException("ভিডিওর তথ্য পড়া যায়নি"))
    }

    fun cancel(id: String) {
        try {
            YoutubeDL.getInstance().destroyProcessById("info-$id")
        } catch (_: Throwable) {
        }
    }
}
