package com.mdsohel.shldownloader

import android.app.Application
import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Engine.start(this)
    }
}

/** Starts the on-phone yt-dlp + ffmpeg engine and keeps yt-dlp up to date. */
object Engine {
    private val statusFlow = MutableStateFlow("ইঞ্জিন প্রস্তুত হচ্ছে…")
    val status: StateFlow<String> = statusFlow.asStateFlow()

    @Volatile
    var error: String? = null
    private val ready = CompletableDeferred<Boolean>()

    fun start(app: Application) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                ready.complete(true)
                statusFlow.value = "ইঞ্জিন প্রস্তুত ✓  ·  ভিডিও: Movies/SHL Downloader, MP3: Music/SHL Downloader"
            } catch (e: Throwable) {
                error = e.message ?: e.toString()
                ready.complete(false)
                statusFlow.value = "ইঞ্জিন চালু হয়নি: $error"
                return@launch
            }
            // keep yt-dlp fresh (sites change often): at most once a day
            val now = System.currentTimeMillis()
            if (now - Prefs.lastUpdate(app) > 24L * 3600_000L) {
                try {
                    YoutubeDL.getInstance().updateYoutubeDL(app)
                    Prefs.setLastUpdate(app, now)
                } catch (_: Throwable) {
                    // offline or GitHub unreachable: keep the bundled version
                }
            }
        }
    }

    suspend fun awaitReady(): Boolean = ready.await()

    /** Manual update button. Returns a short message for the user. */
    fun update(ctx: Context): String = try {
        YoutubeDL.getInstance().updateYoutubeDL(ctx)
        Prefs.setLastUpdate(ctx, System.currentTimeMillis())
        "yt-dlp আপডেট সম্পন্ন ✓"
    } catch (e: Throwable) {
        "আপডেট ব্যর্থ: ${e.message}"
    }
}
