package com.mdsohel.shldownloader

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** status: queued | running | done | error | cancelled */
data class DlJob(
    val id: String,
    val url: String,
    val mode: String,            // "video" | "audio"
    val height: Int?,
    val title: String = "",
    val status: String = "queued",
    val percent: Float = 0f,
    val eta: Long = -1L,
    val text: String = "",
    val error: String = "",
    val saved: String = "",      // content:// uri of the saved file
    val elapsed: Int = 0          // seconds spent preparing (shown while the percentage is still 0)
)

object JobStore {
    private val state = MutableStateFlow<List<DlJob>>(emptyList())
    val jobs: StateFlow<List<DlJob>> = state.asStateFlow()

    fun add(job: DlJob) { state.update { listOf(job) + it } }
    fun get(id: String): DlJob? = state.value.firstOrNull { it.id == id }
    fun update(id: String, change: (DlJob) -> DlJob) {
        state.update { list -> list.map { if (it.id == id) change(it) else it } }
    }
    fun remove(id: String) { state.update { list -> list.filter { it.id != id } } }
    fun clearFinished() { state.update { list -> list.filter { it.status == "queued" || it.status == "running" } } }
    fun hasActive(): Boolean = state.value.any { it.status == "queued" || it.status == "running" }
}
