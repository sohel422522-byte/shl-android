package com.mdsohel.shldownloader

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class JobAdapter(
    private val onCancel: (DlJob) -> Unit,
    private val onOpen: (DlJob) -> Unit,
    private val onRemove: (DlJob) -> Unit
) : ListAdapter<DlJob, JobAdapter.VH>(Diff) {

    object Diff : DiffUtil.ItemCallback<DlJob>() {
        override fun areItemsTheSame(a: DlJob, b: DlJob): Boolean = a.id == b.id
        override fun areContentsTheSame(a: DlJob, b: DlJob): Boolean = a == b
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.tvTitle)
        val status: TextView = v.findViewById(R.id.tvStatus)
        val error: TextView = v.findViewById(R.id.tvError)
        val bar: ProgressBar = v.findViewById(R.id.bar)
        val cancel: Button = v.findViewById(R.id.btnCancel)
        val open: Button = v.findViewById(R.id.btnOpen)
        val remove: Button = v.findViewById(R.id.btnRemove)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_job, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val j = getItem(position)
        val active = j.status == "queued" || j.status == "running"
        h.title.text = (if (j.mode == "audio") "♫ " else "▶ ") + j.title.ifBlank { j.url }
        h.status.text = when (j.status) {
            "done" -> "সম্পন্ন ✓ — ফোনে সেভ হয়েছে"
            "error" -> "ব্যর্থ"
            "cancelled" -> "বাতিল"
            else -> buildString {
                append(j.text.ifBlank { "লাইনে আছে" })
                if (j.percent > 0f) append(" · ${j.percent.toInt()}%")
                if (j.eta > 0L) append(" · ${Logic.formatEta(j.eta)}")
            }
        }
        h.bar.visibility = if (active) View.VISIBLE else View.GONE
        h.bar.isIndeterminate = j.percent <= 0f
        h.bar.progress = j.percent.toInt()
        h.error.visibility = if (j.error.isNotBlank()) View.VISIBLE else View.GONE
        h.error.text = j.error
        h.cancel.visibility = if (active) View.VISIBLE else View.GONE
        h.open.visibility = if (j.status == "done" && j.saved.isNotBlank()) View.VISIBLE else View.GONE
        h.cancel.setOnClickListener { onCancel(j) }
        h.open.setOnClickListener { onOpen(j) }
        h.remove.setOnClickListener { onRemove(j) }
    }
}
