package com.mdsohel.shldownloader

/** Tiny JSON reader without Android classes (so it can be unit-tested). Objects -> Map, arrays -> List, numbers -> Long/Double. */
object MiniJson {
    fun parse(text: String): Any? {
        val p = Parser(text)
        p.skipWs()
        val v = p.readValue()
        p.skipWs()
        if (p.pos != text.length) throw IllegalArgumentException("unexpected data at ${p.pos}")
        return v
    }

    @Suppress("UNCHECKED_CAST")
    fun asMap(v: Any?): Map<String, Any?>? = v as? Map<String, Any?>

    @Suppress("UNCHECKED_CAST")
    fun asList(v: Any?): List<Any?>? = v as? List<Any?>

    fun asString(v: Any?): String? = v as? String

    fun asLong(v: Any?): Long? = when (v) {
        is Long -> v
        is Double -> v.toLong()
        else -> null
    }

    private class Parser(val s: String) {
        var pos = 0

        fun skipWs() {
            while (pos < s.length && s[pos].isWhitespace()) pos++
        }

        fun readValue(): Any? {
            if (pos >= s.length) throw IllegalArgumentException("unexpected end")
            val c = s[pos]
            return when {
                c == '{' -> readObject()
                c == '[' -> readArray()
                c == '"' -> readString()
                c == 't' -> literal("true", true)
                c == 'f' -> literal("false", false)
                c == 'n' -> literal("null", null)
                c == '-' || c.isDigit() -> readNumber()
                else -> throw IllegalArgumentException("bad character '$c' at $pos")
            }
        }

        private fun literal(word: String, value: Any?): Any? {
            if (!s.startsWith(word, pos)) throw IllegalArgumentException("bad literal at $pos")
            pos += word.length
            return value
        }

        private fun readNumber(): Any {
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '-' || s[pos] == '+' || s[pos] == '.' || s[pos] == 'e' || s[pos] == 'E')) pos++
            val t = s.substring(start, pos)
            return if (t.contains('.') || t.contains('e') || t.contains('E')) t.toDouble() else (t.toLongOrNull() ?: t.toDouble())
        }

        private fun readString(): String {
            pos++ // opening quote
            val sb = StringBuilder()
            while (true) {
                if (pos >= s.length) throw IllegalArgumentException("unterminated string")
                val c = s[pos++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        val e = s[pos++]
                        when (e) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                sb.append(s.substring(pos, pos + 4).toInt(16).toChar())
                                pos += 4
                            }
                            else -> throw IllegalArgumentException("bad escape \\$e")
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        private fun readArray(): List<Any?> {
            pos++
            val list = ArrayList<Any?>()
            skipWs()
            if (s[pos] == ']') { pos++; return list }
            while (true) {
                skipWs()
                list.add(readValue())
                skipWs()
                val c = s[pos++]
                if (c == ']') return list
                if (c != ',') throw IllegalArgumentException("expected , or ] at ${pos - 1}")
            }
        }

        private fun readObject(): Map<String, Any?> {
            pos++
            val map = LinkedHashMap<String, Any?>()
            skipWs()
            if (s[pos] == '}') { pos++; return map }
            while (true) {
                skipWs()
                if (s[pos] != '"') throw IllegalArgumentException("expected key at $pos")
                val key = readString()
                skipWs()
                if (s[pos++] != ':') throw IllegalArgumentException("expected : at ${pos - 1}")
                skipWs()
                map[key] = readValue()
                skipWs()
                val c = s[pos++]
                if (c == '}') return map
                if (c != ',') throw IllegalArgumentException("expected , or } at ${pos - 1}")
            }
        }
    }
}
