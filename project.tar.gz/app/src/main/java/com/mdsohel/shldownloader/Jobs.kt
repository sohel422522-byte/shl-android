package com.mdsohel.shldownloader

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import java.util.UUID

object Jobs {
    /** Adds a download to the list and starts the background service for it. */
    fun enqueue(ctx: Context, url: String, mode: String, height: Int?, infoPath: String = "", title: String = "") {
        val id = UUID.randomUUID().toString().take(12)
        JobStore.add(
            DlJob(
                id = id, url = url, mode = mode, height = height,
                title = title.ifBlank { url }, text = "লাইনে আছে", infoPath = infoPath
            )
        )
        ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java).putExtra("id", id))
    }
}
