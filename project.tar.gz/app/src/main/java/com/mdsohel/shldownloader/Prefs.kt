package com.mdsohel.shldownloader

import android.content.Context
import android.net.Uri

object Prefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("shl", Context.MODE_PRIVATE)

    fun tree(ctx: Context): Uri? = p(ctx).getString("tree", null)?.let { Uri.parse(it) }
    fun setTree(ctx: Context, uri: Uri?) { p(ctx).edit().putString("tree", uri?.toString()).apply() }

    fun lastClip(ctx: Context): String = p(ctx).getString("lastClip", "") ?: ""
    fun setLastClip(ctx: Context, v: String) { p(ctx).edit().putString("lastClip", v).apply() }

    fun lastUpdate(ctx: Context): Long = p(ctx).getLong("lastUpdate", 0L)
    fun setLastUpdate(ctx: Context, v: Long) { p(ctx).edit().putLong("lastUpdate", v).apply() }

    fun fastYt(ctx: Context): Boolean = p(ctx).getBoolean("fastYt", false)
    fun setFastYt(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("fastYt", v).apply() }
}
